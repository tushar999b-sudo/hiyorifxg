package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.HiyoriMainView
import com.example.ui.HiyoriViewModel
import com.example.ui.theme.HiyoriTheme
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {

    private val viewModel: HiyoriViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        // STEP 2: Enable edge-to-edge system insets
        enableEdgeToEdge()

        // STEP 3: Render Hiyori AI companion UI
        setContent {
            val uiState by viewModel.uiState.collectAsState()
            HiyoriTheme(darkTheme = uiState.isDarkTheme) {
                HiyoriMainView(viewModel = viewModel)
            }
        }
    }
}
