package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.dao.AuditLogDao
import com.example.data.dao.ChatMessageDao
import com.example.data.dao.MemoryDao
import com.example.data.model.AuditLogEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.MemoryEntity

@Database(
    entities = [
        MemoryEntity::class,
        AuditLogEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class HiyoriDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        @Volatile
        private var INSTANCE: HiyoriDatabase? = null

        fun getInstance(context: Context): HiyoriDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HiyoriDatabase::class.java,
                    "hiyori_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
