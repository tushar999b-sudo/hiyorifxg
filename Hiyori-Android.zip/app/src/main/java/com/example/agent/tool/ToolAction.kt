package com.example.agent.tool

enum class PermissionLevel(val level: Int, val title: String, val requiresUserConfirmation: Boolean) {
    LEVEL_0(0, "Read-Only (Safe)", false),
    LEVEL_1(1, "Safe Local Actions", false),
    LEVEL_2(2, "Computer Interaction", true),
    LEVEL_3(3, "External Communication", true),
    LEVEL_4(4, "System / Terminal Commands", true);

    companion object {
        fun fromInt(level: Int): PermissionLevel = entries.find { it.level == level } ?: LEVEL_2
    }
}

data class ToolDefinition(
    val name: String,
    val description: String,
    val permissionLevel: PermissionLevel,
    val parameterSchemaDescription: String
)

data class ToolCallRequest(
    val callId: String,
    val toolName: String,
    val parameters: Map<String, Any>,
    val permissionLevel: PermissionLevel
)

data class ToolExecutionResult(
    val callId: String,
    val toolName: String,
    val success: Boolean,
    val resultMessage: String,
    val data: Map<String, Any> = emptyMap(),
    val error: String? = null
)
