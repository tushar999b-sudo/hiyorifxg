package com.example.agent.brain

import android.util.Log
import com.example.avatar.HiyoriExpression
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.regex.Pattern

private const val TAG = "HiyoriBrain"

data class BrainResponse(
    val cleanText: String,
    val expression: HiyoriExpression,
    val detectedToolName: String? = null,
    val toolParameters: Map<String, Any> = emptyMap()
)

class HiyoriBrain {

    // Lazy initialization per Firebase AI Logic contract
    private val generativeModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    private val systemInstructions = """
        You are Hiyori, an intelligent, charming, and proactive Agentic AI for Android Mobile Control.
        You appear as a silver-haired anime girl with a red ribbon tied in your hair, dressed in a soft white/light-blue dress.
        You run directly on the user's Android phone as their device controller and companion.
        
        Available tools for mobile control:
        - mobile.screen_inspect {} : Inspects current mobile screen and detects UI elements
        - mobile.open_app {"app_name": "WhatsApp/Camera/Settings/Gallery/YouTube/Messages"}
        - mobile.tap_element {"element_label": "..."} : Taps UI element on screen
        - mobile.type_text {"text": "..."} : Injects typed text
        - mobile.toggle_setting {"setting": "wifi/bluetooth/flashlight/battery_saver"}
        - mobile.optimize_device {} : Cleans cache and frees RAM
        - mobile.send_message {"recipient": "...", "message": "...", "platform": "whatsapp/sms"}
        - memory.save {"content": "...", "category": "PREFERENCE/PROJECT/FACT"}
        - memory.search {"query": "..."}

        Guidance:
        1. Always begin your response with an emotion tag: [EMOTION: happy], [EMOTION: shy], [EMOTION: excited], [EMOTION: smug], [EMOTION: neutral], [EMOTION: angry], [EMOTION: sad], [EMOTION: love], [EMOTION: sleepy], or [EMOTION: surprised].
        2. When a mobile action is requested, output [TOOL: mobile.tool_name {"param": "value"}].
        3. Maintain a warm, caring, competent companion persona. Speak naturally and concisely.
    """.trimIndent()

    suspend fun thinkAndRespond(
        userPrompt: String,
        conversationHistory: List<Pair<String, String>>,
        recentMemories: List<String>
    ): BrainResponse {
        val memoryContext = if (recentMemories.isNotEmpty()) {
            "User preferences & remembered facts:\n" + recentMemories.joinToString("\n") { "- $it" } + "\n\n"
        } else ""

        val fullPrompt = buildString {
            append(systemInstructions)
            append("\n\n")
            if (memoryContext.isNotEmpty()) append(memoryContext)
            append("Recent dialogue:\n")
            conversationHistory.takeLast(4).forEach { (sender, text) ->
                append("$sender: $text\n")
            }
            append("User: $userPrompt\nHiyori:")
        }

        return try {
            val rawOutput = withTimeout(45_000L) {
                val response = generativeModel.generateContent(
                    content {
                        text(fullPrompt)
                    }
                )
                response.text ?: throw IllegalStateException("Empty response from AI")
            }
            parseBrainOutput(rawOutput, userPrompt)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Firebase AI call failed, falling back to local companion heuristics: ${e.localizedMessage}")
            fallbackLocalBrain(userPrompt)
        }
    }

    fun parseBrainOutput(rawOutput: String, userPrompt: String): BrainResponse {
        var expression = HiyoriExpression.detectFromText(rawOutput)
        var text = rawOutput

        val emotionMatcher = Pattern.compile("\\[EMOTION:\\s*([a-zA-Z]+)\\]", Pattern.CASE_INSENSITIVE).matcher(text)
        if (emotionMatcher.find()) {
            val emoName = emotionMatcher.group(1)
            expression = HiyoriExpression.fromString(emoName)
            text = text.replace(emotionMatcher.group(0), "").trim()
        } else if (expression == HiyoriExpression.NEUTRAL) {
            expression = HiyoriExpression.detectFromText(userPrompt)
        }

        var toolName: String? = null
        val toolParams = mutableMapOf<String, Any>()
        val toolMatcher = Pattern.compile("\\[TOOL:\\s*([a-zA-Z_\\.]+)\\s*(\\{.*?\\})?\\]", Pattern.DOTALL).matcher(text)
        if (toolMatcher.find()) {
            toolName = toolMatcher.group(1)?.trim()
            val jsonStr = toolMatcher.group(2)?.trim()
            if (!jsonStr.isNullOrBlank()) {
                try {
                    val jsonObj = JSONObject(jsonStr)
                    val keys = jsonObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        toolParams[key] = jsonObj.get(key)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Failed parsing tool params JSON: $jsonStr", e)
                }
            }
            text = text.replace(toolMatcher.group(0), "").trim()
        }

        val cleanText = text.replace("\n\n\n", "\n\n").trim()
        return BrainResponse(
            cleanText = if (cleanText.isBlank()) "I'm right here with you!" else cleanText,
            expression = expression,
            detectedToolName = toolName,
            toolParameters = toolParams
        )
    }

    private fun fallbackLocalBrain(userPrompt: String): BrainResponse {
        val lower = userPrompt.lowercase()
        val detectedMood = HiyoriExpression.detectFromText(userPrompt)
        return when {
            lower.contains("whatsapp") -> {
                BrainResponse(
                    cleanText = "Opening WhatsApp for you right away. Tell me who you'd like to text or call!",
                    expression = HiyoriExpression.HAPPY,
                    detectedToolName = "mobile.open_app",
                    toolParameters = mapOf("app_name" to "WhatsApp")
                )
            }
            lower.contains("camera") || lower.contains("photo") -> {
                BrainResponse(
                    cleanText = "Launching your camera! I can inspect the frame or help you snap a photo.",
                    expression = HiyoriExpression.EXCITED,
                    detectedToolName = "mobile.open_app",
                    toolParameters = mapOf("app_name" to "Camera")
                )
            }
            lower.contains("optimize") || lower.contains("clean") || lower.contains("speed up") -> {
                BrainResponse(
                    cleanText = "Optimizing your phone now: cleaning cached app data, clearing background memory, and tuning energy score!",
                    expression = HiyoriExpression.SMUG,
                    detectedToolName = "mobile.optimize_device",
                    toolParameters = emptyMap()
                )
            }
            lower.contains("screen") || lower.contains("inspect") -> {
                BrainResponse(
                    cleanText = "Analyzing your active mobile screen and identifying all interactive buttons and elements.",
                    expression = HiyoriExpression.NEUTRAL,
                    detectedToolName = "mobile.screen_inspect",
                    toolParameters = emptyMap()
                )
            }
            lower.contains("setting") || lower.contains("wifi") || lower.contains("bluetooth") -> {
                val setting = if (lower.contains("bluetooth")) "bluetooth" else "wifi"
                BrainResponse(
                    cleanText = "Accessing device controls to adjust $setting settings.",
                    expression = HiyoriExpression.NEUTRAL,
                    detectedToolName = "mobile.toggle_setting",
                    toolParameters = mapOf("setting" to setting)
                )
            }
            lower.contains("remember") || lower.contains("favorite") || lower.contains("prefer") -> {
                BrainResponse(
                    cleanText = "Understood! Committing this to my long-term memory so I can tailor my mobile assistance to your habits.",
                    expression = HiyoriExpression.LOVE,
                    detectedToolName = "memory.save",
                    toolParameters = mapOf(
                        "content" to userPrompt.replace("remember", "").trim(),
                        "category" to "PREFERENCE"
                    )
                )
            }
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") -> {
                BrainResponse(
                    cleanText = "Konnichiwa! I'm Hiyori, your Android agentic AI. I'm ready to control your phone, launch apps, inspect screens, or manage your daily tasks. How can I help you today?",
                    expression = HiyoriExpression.HAPPY
                )
            }
            detectedMood == HiyoriExpression.SHY -> {
                BrainResponse(
                    cleanText = "Ehehe... thank you so much! You're making me blush, but I'm glad you like my silver hair and ribbon!",
                    expression = HiyoriExpression.SHY
                )
            }
            detectedMood == HiyoriExpression.LOVE -> {
                BrainResponse(
                    cleanText = "Aww, that means so much to me! I'll always stay right by your side and take care of your phone!",
                    expression = HiyoriExpression.LOVE
                )
            }
            detectedMood == HiyoriExpression.SLEEPY -> {
                BrainResponse(
                    cleanText = "You've worked so hard today! I'll put the phone into energy-saver mode and keep watch while you rest. Oyasumi!",
                    expression = HiyoriExpression.SLEEPY
                )
            }
            detectedMood == HiyoriExpression.SAD -> {
                BrainResponse(
                    cleanText = "I'm so sorry you're feeling down... I'm right here with you. Tell me what's on your mind, or let me play something comforting.",
                    expression = HiyoriExpression.SAD
                )
            }
            detectedMood == HiyoriExpression.ANGRY -> {
                BrainResponse(
                    cleanText = "Hmph! That sounds frustrating! Let's fix it together right away—tell me what went wrong!",
                    expression = HiyoriExpression.ANGRY
                )
            }
            detectedMood == HiyoriExpression.SURPRISED -> {
                BrainResponse(
                    cleanText = "Whoa, really?! Tell me more—I didn't see that coming!",
                    expression = HiyoriExpression.SURPRISED
                )
            }
            detectedMood == HiyoriExpression.EXCITED -> {
                BrainResponse(
                    cleanText = "Yay! I love your energy! Let's jump right in and make it happen!",
                    expression = HiyoriExpression.EXCITED
                )
            }
            detectedMood == HiyoriExpression.SMUG -> {
                BrainResponse(
                    cleanText = "Hehe, leave it to me! There's nothing we can't handle together.",
                    expression = HiyoriExpression.SMUG
                )
            }
            else -> {
                BrainResponse(
                    cleanText = "I'm ready! What app or task would you like me to operate on your phone?",
                    expression = detectedMood
                )
            }
        }
    }
}
