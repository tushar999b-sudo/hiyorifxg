package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.agent.tool.PermissionLevel
import com.example.agent.tool.ToolCallRequest
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CardWhite
import com.example.ui.theme.MintCyan
import com.example.ui.theme.SoftLilac
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMutedDark
import org.json.JSONObject

@Composable
fun PermissionDialog(
    request: ToolCallRequest,
    onApprove: () -> Unit,
    onDeny: () -> Unit
) {
    val levelColor = when (request.permissionLevel) {
        PermissionLevel.LEVEL_4 -> Color(0xFFEF4444)
        PermissionLevel.LEVEL_3 -> Color(0xFFF59E0B)
        else -> MintCyan
    }

    Dialog(onDismissRequest = onDeny) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = CardWhite,
            border = BorderStroke(1.5.dp, levelColor),
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp), spotColor = levelColor.copy(alpha = 0.3f))
                .testTag("permission_dialog")
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Icon & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (request.permissionLevel == PermissionLevel.LEVEL_4) Icons.Default.Warning else Icons.Default.Lock,
                        contentDescription = "Security",
                        tint = levelColor,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(
                        text = "Agent Permission Check",
                        color = TextDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Level Badge
                Surface(
                    color = levelColor.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, levelColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "LEVEL ${request.permissionLevel.level}: ${request.permissionLevel.title.uppercase()}",
                        color = levelColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Hiyori requires your confirmation before operating this action on your mobile device:",
                    color = TextMutedDark,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Action Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF8FAFC))
                        .border(1.dp, BorderLight, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "Tool: ${request.toolName}",
                            color = TextDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Parameters:\n${JSONObject(request.parameters).toString(2)}",
                            color = MintCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDeny,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("deny_tool_button")
                    ) {
                        Text("Deny", color = TextMutedDark)
                    }

                    Button(
                        onClick = onApprove,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = levelColor,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("approve_tool_button")
                    ) {
                        Text("Authorize", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
