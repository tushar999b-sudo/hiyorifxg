package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.agent.brain.HiyoriBrain
import com.example.agent.tool.PcBridgeClient
import com.example.agent.tool.PcBridgeStatus
import com.example.agent.tool.PermissionLevel
import com.example.agent.tool.ToolCallRequest
import com.example.agent.tool.ToolExecutionResult
import com.example.agent.tool.ToolRegistry
import com.example.avatar.HiyoriExpression
import com.example.data.database.HiyoriDatabase
import com.example.data.model.ActionStatus
import com.example.data.model.AuditLogEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryEntity
import com.example.data.model.MessageSender
import com.example.voice.VoiceController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

enum class CompanionTab(val title: String) {
    OVERVIEW("Overview"),
    AGENT_HUB("Agent Hub"),
    CONTROLS("Controls"),
    CHAT("AI Chat"),
    MEMORY("Memory")
}

data class MobileDeviceStats(
    val energyScore: Int = 94,
    val batteryPercent: Int = 88,
    val ramFreeGb: Float = 3.6f,
    val storageFreeGb: Float = 78.4f,
    val securityStatus: String = "Shielded",
    val activeTask: String? = null
)

data class HiyoriUiState(
    val activeTab: CompanionTab = CompanionTab.AGENT_HUB,
    val currentExpression: HiyoriExpression = HiyoriExpression.NEUTRAL,
    val isThinking: Boolean = false,
    val isSpeaking: Boolean = false,
    val isListening: Boolean = false,
    val voiceMuted: Boolean = false,
    val pendingPermissionRequest: ToolCallRequest? = null,
    val lastExecutedToolResult: ToolExecutionResult? = null,
    val screenVisionPreview: Map<String, Any>? = null,
    val speechWaveformIntensity: Float = 0f,
    val notificationMessage: String? = null,
    val deviceStats: MobileDeviceStats = MobileDeviceStats(),
    val isDarkTheme: Boolean = true,
    val remainingActions: Int = 50
)

class HiyoriViewModel(application: Application) : AndroidViewModel(application) {

    private val database = HiyoriDatabase.getInstance(application)
    private val memoryDao = database.memoryDao()
    private val auditLogDao = database.auditLogDao()
    private val chatMessageDao = database.chatMessageDao()

    val pcBridgeClient = PcBridgeClient()
    val toolRegistry = ToolRegistry(pcBridgeClient, memoryDao, application)
    val brain = HiyoriBrain()
    val voiceController = VoiceController(application)

    private val _uiState = MutableStateFlow(HiyoriUiState())
    val uiState: StateFlow<HiyoriUiState> = _uiState.asStateFlow()

    val pcStatus: StateFlow<PcBridgeStatus> = pcBridgeClient.status

    val chatMessages: StateFlow<List<ChatMessageEntity>> = chatMessageDao.getAllMessagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryEntity>> = memoryDao.getAllMemoriesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = auditLogDao.getRecentLogsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Collect TTS / STT state
        viewModelScope.launch {
            voiceController.isSpeaking.collect { speaking ->
                _uiState.value = _uiState.value.copy(
                    isSpeaking = speaking,
                    speechWaveformIntensity = if (speaking) 0.8f else 0f
                )
            }
        }
        viewModelScope.launch {
            voiceController.isListening.collect { listening ->
                _uiState.value = _uiState.value.copy(isListening = listening)
            }
        }
        viewModelScope.launch {
            voiceController.voiceMuted.collect { muted ->
                _uiState.value = _uiState.value.copy(voiceMuted = muted)
            }
        }

        // Initialize starter memory & welcome message
        viewModelScope.launch {
            if (memoryDao.getAllMemories().isEmpty()) {
                memoryDao.insertMemory(
                    MemoryEntity(
                        category = MemoryCategory.PREFERENCE.name,
                        content = "User prefers automated screen perception and WhatsApp agentic shortcuts.",
                        importance = 4
                    )
                )
                memoryDao.insertMemory(
                    MemoryEntity(
                        category = MemoryCategory.PROJECT.name,
                        content = "Active agent: Hiyori Mobile Controller with Gemini 3.8 Flash.",
                        importance = 5
                    )
                )
            }

            if (chatMessageDao.getRecentMessages(1).isEmpty()) {
                val greeting = "Hi Master! I'm Hiyori, your Android agentic AI companion. I'm connected to your phone's controls, voice, and apps. How can I assist you today?"
                chatMessageDao.insertMessage(
                    ChatMessageEntity(
                        sender = MessageSender.HIYORI.name,
                        content = greeting,
                        expression = HiyoriExpression.HAPPY.name
                    )
                )
                voiceController.speak(greeting)
            }
        }
    }

    fun selectTab(tab: CompanionTab) {
        _uiState.value = _uiState.value.copy(activeTab = tab)
    }

    fun toggleTheme() {
        _uiState.value = _uiState.value.copy(isDarkTheme = !_uiState.value.isDarkTheme)
    }

    fun setExpression(expression: HiyoriExpression) {
        _uiState.value = _uiState.value.copy(currentExpression = expression)
    }

    fun pokeAvatar() {
        val expressions = listOf(
            HiyoriExpression.SHY,
            HiyoriExpression.HAPPY,
            HiyoriExpression.SURPRISED,
            HiyoriExpression.SMUG,
            HiyoriExpression.LOVE
        )
        val next = expressions.random()
        setExpression(next)
        val phrase = when (next) {
            HiyoriExpression.SHY -> "Ehehe... that tickles! What can I control for you?"
            HiyoriExpression.HAPPY -> "Yay! Always so happy to hear from you!"
            HiyoriExpression.SURPRISED -> "W-whoa! You surprised me!"
            HiyoriExpression.SMUG -> "Need your favorite mobile agent? You got me!"
            HiyoriExpression.LOVE -> "I'm always watching over your phone!"
            else -> "I'm right here!"
        }
        voiceController.speak(phrase)
    }

    fun toggleVoiceMute() {
        voiceController.toggleMute()
    }

    fun startVoiceListening() {
        voiceController.startListening { transcribedText ->
            sendMessage(transcribedText)
        }
    }

    fun stopVoiceListening() {
        voiceController.stopListening()
    }

    fun updateMoodFromDraft(draft: String) {
        if (draft.isBlank()) return
        val detected = HiyoriExpression.detectFromText(draft)
        if (detected != HiyoriExpression.NEUTRAL && detected != _uiState.value.currentExpression) {
            _uiState.value = _uiState.value.copy(currentExpression = detected)
        }
    }

    fun sendMessage(content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            chatMessageDao.insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.USER.name,
                    content = content
                )
            )

            val userMood = HiyoriExpression.detectFromText(content)
            _uiState.value = _uiState.value.copy(
                isThinking = true,
                currentExpression = userMood,
                remainingActions = (_uiState.value.remainingActions - 1).coerceAtLeast(0)
            )

            val history = chatMessageDao.getRecentMessages(6).map { it.sender to it.content }.reversed()
            val memoriesList = memoryDao.getAllMemories().take(6).map { "[${it.category}] ${it.content}" }

            val response = brain.thinkAndRespond(content, history, memoriesList)

            _uiState.value = _uiState.value.copy(
                isThinking = false,
                currentExpression = response.expression
            )

            chatMessageDao.insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.HIYORI.name,
                    content = response.cleanText,
                    expression = response.expression.name,
                    toolActionName = response.detectedToolName,
                    toolStatus = if (response.detectedToolName != null) "STAGED" else null
                )
            )

            voiceController.speak(response.cleanText)

            if (response.detectedToolName != null) {
                val toolDef = toolRegistry.findTool(response.detectedToolName)
                val permLevel = toolDef?.permissionLevel ?: PermissionLevel.LEVEL_2

                val request = ToolCallRequest(
                    callId = UUID.randomUUID().toString(),
                    toolName = response.detectedToolName,
                    parameters = response.toolParameters,
                    permissionLevel = permLevel
                )

                if (permLevel.requiresUserConfirmation) {
                    auditLogDao.insertLog(
                        AuditLogEntity(
                            actionName = request.toolName,
                            target = request.parameters["app_name"] as? String
                                ?: request.parameters["recipient"] as? String
                                ?: request.parameters["setting"] as? String
                                ?: "Mobile Device",
                            parametersJson = JSONObject(request.parameters).toString(),
                            permissionLevel = permLevel.level,
                            status = ActionStatus.PENDING_APPROVAL.name
                        )
                    )
                    _uiState.value = _uiState.value.copy(pendingPermissionRequest = request)
                } else {
                    executeToolDirectly(request)
                }
            }
        }
    }

    fun approvePendingTool() {
        val request = _uiState.value.pendingPermissionRequest ?: return
        _uiState.value = _uiState.value.copy(pendingPermissionRequest = null)
        executeToolDirectly(request)
    }

    fun denyPendingTool() {
        val request = _uiState.value.pendingPermissionRequest ?: return
        viewModelScope.launch {
            auditLogDao.insertLog(
                AuditLogEntity(
                    actionName = request.toolName,
                    target = "Mobile Action Denied",
                    parametersJson = JSONObject(request.parameters).toString(),
                    permissionLevel = request.permissionLevel.level,
                    status = ActionStatus.REJECTED.name,
                    resultDetails = "Denied by user"
                )
            )
            _uiState.value = _uiState.value.copy(
                pendingPermissionRequest = null,
                currentExpression = HiyoriExpression.ANGRY,
                notificationMessage = "Action ${request.toolName} was denied."
            )
            chatMessageDao.insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.SYSTEM.name,
                    content = "Permission for ${request.toolName} was rejected by user."
                )
            )
        }
    }

    private fun executeToolDirectly(request: ToolCallRequest) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(currentExpression = HiyoriExpression.EXCITED)
            val result = toolRegistry.execute(request)

            auditLogDao.insertLog(
                AuditLogEntity(
                    actionName = request.toolName,
                    target = result.toolName,
                    parametersJson = JSONObject(request.parameters).toString(),
                    permissionLevel = request.permissionLevel.level,
                    status = if (result.success) ActionStatus.SUCCESS.name else ActionStatus.FAILED.name,
                    resultDetails = result.resultMessage
                )
            )

            // Dynamic device metric updates
            var newStats = _uiState.value.deviceStats
            if (request.toolName == "mobile.optimize_device") {
                newStats = newStats.copy(
                    energyScore = 98,
                    ramFreeGb = 4.1f
                )
            }

            _uiState.value = _uiState.value.copy(
                lastExecutedToolResult = result,
                currentExpression = if (result.success) HiyoriExpression.SMUG else HiyoriExpression.SAD,
                screenVisionPreview = if (request.toolName == "mobile.screen_inspect") result.data else _uiState.value.screenVisionPreview,
                notificationMessage = result.resultMessage,
                deviceStats = newStats
            )

            chatMessageDao.insertMessage(
                ChatMessageEntity(
                    sender = MessageSender.SYSTEM.name,
                    content = "📱 ${result.resultMessage}",
                    toolActionName = result.toolName,
                    toolStatus = if (result.success) "SUCCESS" else "FAILED"
                )
            )
        }
    }

    fun triggerQuickAction(actionName: String, params: Map<String, Any>) {
        val toolDef = toolRegistry.findTool(actionName)
        val perm = toolDef?.permissionLevel ?: PermissionLevel.LEVEL_2
        val request = ToolCallRequest(
            callId = UUID.randomUUID().toString(),
            toolName = actionName,
            parameters = params,
            permissionLevel = perm
        )
        if (perm.requiresUserConfirmation) {
            _uiState.value = _uiState.value.copy(pendingPermissionRequest = request)
        } else {
            executeToolDirectly(request)
        }
    }

    fun optimizeDevice() {
        triggerQuickAction("mobile.optimize_device", emptyMap())
    }

    fun inspectScreen() {
        triggerQuickAction("mobile.screen_inspect", emptyMap())
    }

    fun connectPc(host: String) {
        viewModelScope.launch {
            pcBridgeClient.connect(host)
        }
    }

    fun disconnectPc() {
        pcBridgeClient.disconnect()
    }

    fun toggleSimulatedBridge() {
        pcBridgeClient.toggleSimulatedBridge()
    }

    fun saveMemory(content: String, category: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            memoryDao.insertMemory(
                MemoryEntity(
                    category = category,
                    content = content,
                    importance = 4
                )
            )
            _uiState.value = _uiState.value.copy(
                currentExpression = HiyoriExpression.LOVE,
                notificationMessage = "Saved to $category memory!"
            )
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            memoryDao.deleteMemoryById(id)
            _uiState.value = _uiState.value.copy(
                notificationMessage = "Memory deleted."
            )
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            chatMessageDao.clearChat()
        }
    }

    fun clearAuditLogs() {
        viewModelScope.launch {
            auditLogDao.clearLogs()
        }
    }

    fun dismissNotification() {
        _uiState.value = _uiState.value.copy(notificationMessage = null)
    }

    override fun onCleared() {
        super.onCleared()
        voiceController.destroy()
    }
}
