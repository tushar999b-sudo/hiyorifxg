package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.avatar.HiyoriExpression
import com.example.data.model.ChatMessageEntity
import com.example.data.model.MessageSender
import com.example.ui.HiyoriUiState
import com.example.ui.theme.HiyoriThemeTokens

@Composable
fun CompanionScreen(
    uiState: HiyoriUiState,
    chatMessages: List<ChatMessageEntity>,
    onSendMessage: (String) -> Unit,
    onToggleVoiceMute: () -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onDraftMoodPreview: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = HiyoriThemeTokens.colors
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .imePadding()
    ) {
        // Minimal Live Hiyori Mood Bar
        val currentExpr = uiState.currentExpression
        Surface(
            color = colors.card,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, colors.border),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("chat_live_mood_bar")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Crossfade(
                    targetState = currentExpr,
                    animationSpec = tween(durationMillis = 260),
                    label = "chat_avatar_mood"
                ) { expr ->
                    Image(
                        painter = painterResource(id = expr.baseDrawableRes),
                        contentDescription = "Hiyori ${expr.title}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, colors.accent, CircleShape)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Hiyori",
                            color = colors.textPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = colors.accentSoft,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = currentExpr.title,
                                color = colors.accent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = when {
                            uiState.isThinking -> "Sensing mood & thinking..."
                            uiState.isListening -> "Listening..."
                            uiState.isSpeaking -> "Speaking..."
                            else -> currentExpr.emotionNote
                        },
                        color = colors.textSecondary,
                        fontSize = 11.5.sp
                    )
                }
            }
        }

        // Minimal Message Thread
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            items(chatMessages, key = { it.id }) { msg ->
                ChatMessageItem(
                    msg = msg,
                    onActionChipClick = { actionPrompt -> onSendMessage(actionPrompt) }
                )
            }

            if (uiState.isThinking) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 6.dp, top = 4.dp)
                    ) {
                        CircularProgressIndicator(
                            color = colors.accent,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Hiyori is reasoning & planning",
                            color = colors.textSecondary,
                            fontSize = 12.5.sp
                        )
                    }
                }
            }
        }

        // Same Pill Input Bar as Agent Hub
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            PillPromptInputBar(
                inputText = inputText,
                isListening = uiState.isListening,
                onTextChange = {
                    inputText = it
                    onDraftMoodPreview(it)
                },
                onSend = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText.trim())
                        inputText = ""
                    }
                },
                onAttachClick = { onSendMessage("Inspect screen OCR") },
                onImageClick = { onSendMessage("Open Camera for vision") },
                onMicToggle = {
                    if (uiState.isListening) onStopVoice() else onStartVoice()
                },
                inputTestTag = "chat_input",
                sendTestTag = "chat_send_btn"
            )
        }
    }
}

@Composable
private fun ChatMessageItem(
    msg: ChatMessageEntity,
    onActionChipClick: (String) -> Unit
) {
    val colors = HiyoriThemeTokens.colors
    val isUser = msg.sender == MessageSender.USER.name
    val isSystem = msg.sender == MessageSender.SYSTEM.name

    if (isSystem) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                color = colors.surfaceSubtle,
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, colors.border)
            ) {
                Text(
                    text = msg.content,
                    color = colors.textSecondary,
                    fontSize = 11.5.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }
        return
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            val expr = HiyoriExpression.fromString(msg.expression)
            Image(
                painter = painterResource(id = expr.baseDrawableRes),
                contentDescription = "Hiyori",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, colors.accent, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
        }

        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.fillMaxWidth(0.84f)
        ) {
            Surface(
                color = if (isUser) colors.accentSoft else colors.card,
                shape = RoundedCornerShape(
                    topStart = 20.dp,
                    topEnd = 20.dp,
                    bottomStart = if (isUser) 20.dp else 6.dp,
                    bottomEnd = if (isUser) 6.dp else 20.dp
                ),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (isUser) colors.accent.copy(alpha = 0.3f) else colors.border
                ),
                shadowElevation = if (colors.isDark || isUser) 0.dp else 2.dp
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    if (!isUser) {
                        val expr = HiyoriExpression.fromString(msg.expression)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Hiyori",
                                color = colors.textPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = colors.accentSoft,
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = expr.title,
                                    color = colors.accent,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Text(
                        text = msg.content,
                        color = colors.textPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            // Action chips under Hiyori's replies
            if (!isUser) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (msg.toolActionName != null) {
                        Surface(
                            color = colors.accentSoft,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f))
                        ) {
                            Text(
                                text = "${msg.toolActionName} • ${msg.toolStatus ?: "DONE"}",
                                color = colors.accent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    } else {
                        Surface(
                            color = colors.card,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, colors.border),
                            modifier = Modifier.clickable { onActionChipClick("Inspect screen OCR") }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Visibility,
                                    contentDescription = "Inspect screen OCR",
                                    tint = colors.accent,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Inspect screen OCR",
                                    color = colors.textSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
