package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class HiyoriColors(
    val isDark: Boolean,
    val background: Color,
    val card: Color,
    val surfaceSubtle: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val accentSoft: Color,
    val secondaryAccent: Color,
    val characterGlow: Color
)

val LocalHiyoriColors = staticCompositionLocalOf {
    HiyoriColors(
        isDark = false,
        background = LightBg,
        card = LightCard,
        surfaceSubtle = LightSurfaceSubtle,
        border = LightBorder,
        textPrimary = LightTextPrimary,
        textSecondary = LightTextSecondary,
        accent = MintTeal,
        accentSoft = MintTeal.copy(alpha = 0.14f),
        secondaryAccent = SoftIndigo,
        characterGlow = MintTeal.copy(alpha = 0.16f)
    )
}

object HiyoriThemeTokens {
    val colors: HiyoriColors
        @Composable
        @ReadOnlyComposable
        get() = LocalHiyoriColors.current
}

private val HiyoriLightColorScheme = lightColorScheme(
    primary = MintTeal,
    onPrimary = Color(0xFF0B2920),
    primaryContainer = Color(0xFFE2F8F0),
    onPrimaryContainer = Color(0xFF0B3B2C),
    secondary = SoftIndigo,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE9FE),
    onSecondaryContainer = Color(0xFF2E1065),
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightCard,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceSubtle,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    outlineVariant = LightBorder
)

private val HiyoriDarkColorScheme = darkColorScheme(
    primary = MintTeal,
    onPrimary = Color(0xFF08221A),
    primaryContainer = Color(0xFF15342B),
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = SoftIndigoLight,
    onSecondary = Color(0xFF1A1438),
    secondaryContainer = Color(0xFF252042),
    onSecondaryContainer = Color(0xFFDDD6FE),
    background = DarkBg,
    onBackground = DarkTextPrimary,
    surface = DarkCard,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceSubtle,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    outlineVariant = DarkBorder
)

@Composable
fun HiyoriTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val animSpec = tween<Color>(durationMillis = 280)

    val bg by animateColorAsState(if (darkTheme) DarkBg else LightBg, animSpec, label = "bg")
    val card by animateColorAsState(if (darkTheme) DarkCard else LightCard, animSpec, label = "card")
    val subtle by animateColorAsState(if (darkTheme) DarkSurfaceSubtle else LightSurfaceSubtle, animSpec, label = "subtle")
    val border by animateColorAsState(if (darkTheme) DarkBorder else LightBorder, animSpec, label = "border")
    val textPrimary by animateColorAsState(if (darkTheme) DarkTextPrimary else LightTextPrimary, animSpec, label = "textPrimary")
    val textSecondary by animateColorAsState(if (darkTheme) DarkTextSecondary else LightTextSecondary, animSpec, label = "textSecondary")
    val secondaryAccent by animateColorAsState(if (darkTheme) SoftIndigoLight else SoftIndigo, animSpec, label = "secondaryAccent")

    val hiyoriColors = HiyoriColors(
        isDark = darkTheme,
        background = bg,
        card = card,
        surfaceSubtle = subtle,
        border = border,
        textPrimary = textPrimary,
        textSecondary = textSecondary,
        accent = MintTeal,
        accentSoft = MintTeal.copy(alpha = if (darkTheme) 0.16f else 0.13f),
        secondaryAccent = secondaryAccent,
        characterGlow = MintTeal.copy(alpha = if (darkTheme) 0.22f else 0.15f)
    )

    CompositionLocalProvider(LocalHiyoriColors provides hiyoriColors) {
        MaterialTheme(
            colorScheme = if (darkTheme) HiyoriDarkColorScheme else HiyoriLightColorScheme,
            typography = Typography,
            content = content
        )
    }
}
