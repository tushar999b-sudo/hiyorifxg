package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand & Accent Tokens (Restrained Mint/Teal + Soft Secondary)
val MintTeal = Color(0xFF3ECFA0)
val MintTealDeep = Color(0xFF1FA97C)
val SoftIndigo = Color(0xFF7C6CF0)
val SoftIndigoLight = Color(0xFF9D8DF7)

// Light Mode Palette (Warm Off-White, Crisp White Cards, Dark Gray Text)
val LightBg = Color(0xFFFAF9F6)
val LightCard = Color(0xFFFFFFFF)
val LightSurfaceSubtle = Color(0xFFF2F3F5)
val LightBorder = Color(0xFFE6E8EC)
val LightTextPrimary = Color(0xFF181C24)
val LightTextSecondary = Color(0xFF64748B)

// Dark Mode Palette (Deep Charcoal/Navy #0F1115, Slightly Lighter Cards, Soft White Text)
val DarkBg = Color(0xFF0F1115)
val DarkCard = Color(0xFF161A22)
val DarkSurfaceSubtle = Color(0xFF1E232E)
val DarkBorder = Color(0xFF242A38)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)

// Semantic Status Colors
val GaugeGreen = Color(0xFF3ECFA0)
val GaugeAmber = Color(0xFFF59E0B)
val StatusDanger = Color(0xFFEF4444)

// Legacy aliases preserved for compatibility
val SoftMintBg = LightBg
val SoftSkyBg = Color(0xFFF3F6FA)
val CardWhite = LightCard
val MintCyan = MintTeal
val MintCyanDark = MintTealDeep
val ElectricAzure = Color(0xFF38BDF8)
val SoftLilac = SoftIndigo
val SoftCoral = Color(0xFFF472B6)
val TextDark = LightTextPrimary
val TextMutedDark = LightTextSecondary
val BorderLight = LightBorder
