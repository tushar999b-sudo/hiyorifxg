package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.avatar.HiyoriExpression
import com.example.ui.MobileDeviceStats
import com.example.ui.theme.HiyoriThemeTokens

@Composable
fun OverviewScreen(
    stats: MobileDeviceStats,
    expression: HiyoriExpression,
    onOptimize: () -> Unit,
    onInspectScreen: () -> Unit,
    onOpenWhatsApp: () -> Unit,
    onNavigateToControls: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = HiyoriThemeTokens.colors
    val animatedScore by animateFloatAsState(
        targetValue = (stats.energyScore.coerceIn(0, 100)) / 100f,
        animationSpec = tween(durationMillis = 700),
        label = "device_performance_gauge"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Greeting Header
        Column {
            Text(
                text = "Hi Master,",
                color = colors.textSecondary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Normal
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Hiyori controls your mobile",
                color = colors.textPrimary,
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.4).sp
            )
        }

        // Minimal Circular Gauge Card for Device Performance (94/100)
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = colors.card,
            border = BorderStroke(1.dp, colors.border),
            shadowElevation = if (colors.isDark) 0.dp else 3.dp,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("overview_performance_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp, horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "DEVICE PERFORMANCE",
                    color = colors.textSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                Box(
                    modifier = Modifier.size(148.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val trackColor = colors.surfaceSubtle
                    val accentColor = colors.accent
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 11.dp.toPx()
                        val diameter = size.minDimension - strokeWidth
                        val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                        val arcSize = Size(diameter, diameter)

                        drawArc(
                            color = trackColor,
                            startAngle = 0f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )

                        drawArc(
                            color = accentColor,
                            startAngle = -90f,
                            sweepAngle = 360f * animatedScore,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${stats.energyScore}",
                            color = colors.textPrimary,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "/100",
                            color = colors.textSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Three Small Stat Tiles: Battery 88% normal, Memory 3.6 GB free, Security Shielded
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OverviewStatTile(
                icon = Icons.Outlined.BatteryChargingFull,
                label = "Battery",
                value = "${stats.batteryPercent}%",
                sublabel = "normal",
                modifier = Modifier.weight(1f)
            )
            OverviewStatTile(
                icon = Icons.Outlined.Memory,
                label = "Memory",
                value = "${stats.ramFreeGb} GB",
                sublabel = "free",
                modifier = Modifier.weight(1f)
            )
            OverviewStatTile(
                icon = Icons.Outlined.Shield,
                label = "Security",
                value = stats.securityStatus,
                sublabel = "active",
                modifier = Modifier.weight(1f)
            )
        }

        // Agentic Mobile Control Shortcuts (2-column grid)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "AGENTIC MOBILE CONTROL SHORTCUTS",
                color = colors.textSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShortcutCard(
                    icon = Icons.Outlined.CleaningServices,
                    title = "One-Tap Optimize",
                    subtitle = "Free RAM & cache",
                    onClick = onOptimize,
                    testTag = "shortcut_optimize",
                    modifier = Modifier.weight(1f)
                )
                ShortcutCard(
                    icon = Icons.Outlined.Visibility,
                    title = "Inspect Screen",
                    subtitle = "Read UI & OCR",
                    onClick = onInspectScreen,
                    testTag = "shortcut_inspect",
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShortcutCard(
                    icon = Icons.Outlined.PhoneAndroid,
                    title = "Launch WhatsApp",
                    subtitle = "Quick messaging",
                    onClick = onOpenWhatsApp,
                    testTag = "shortcut_whatsapp",
                    modifier = Modifier.weight(1f)
                )
                ShortcutCard(
                    icon = Icons.Outlined.Tune,
                    title = "Mobile controls",
                    subtitle = "System & bridge",
                    onClick = onNavigateToControls,
                    testTag = "shortcut_controls",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun OverviewStatTile(
    icon: ImageVector,
    label: String,
    value: String,
    sublabel: String,
    modifier: Modifier = Modifier
) {
    val colors = HiyoriThemeTokens.colors
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.border),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = colors.accent,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                color = colors.textSecondary,
                fontSize = 11.5.sp
            )
            Text(
                text = value,
                color = colors.textPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = sublabel,
                color = colors.accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun ShortcutCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val colors = HiyoriThemeTokens.colors
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.card,
        border = BorderStroke(1.dp, colors.border),
        shadowElevation = if (colors.isDark) 0.dp else 2.dp,
        modifier = modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(colors.accentSoft, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = colors.accent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    color = colors.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = colors.textSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}
