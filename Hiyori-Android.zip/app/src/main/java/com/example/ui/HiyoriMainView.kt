package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.VolumeMute
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.PermissionDialog
import com.example.ui.screens.AgentHubScreen
import com.example.ui.screens.CompanionScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PcBridgeScreen
import com.example.ui.theme.HiyoriThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HiyoriMainView(
    viewModel: HiyoriViewModel
) {
    val colors = HiyoriThemeTokens.colors
    val uiState by viewModel.uiState.collectAsState()
    val pcStatus by viewModel.pcStatus.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val memories by viewModel.memories.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.notificationMessage) {
        uiState.notificationMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissNotification()
        }
    }

    BackHandler(enabled = uiState.activeTab != CompanionTab.AGENT_HUB) {
        viewModel.selectTab(CompanionTab.AGENT_HUB)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
        containerColor = colors.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(colors.accent)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "HIYORI",
                            color = colors.textPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = colors.accentSoft,
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f))
                        ) {
                            Text(
                                text = "MOBILE AGENT",
                                color = colors.accent,
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.6.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    // Battery / Performance Pill ("94/100" with lightning icon)
                    Surface(
                        color = colors.card,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, colors.border),
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Bolt,
                                contentDescription = "Performance",
                                tint = colors.accent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${uiState.deviceStats.energyScore}/100",
                                color = colors.textPrimary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Sound Toggle Icon
                    IconButton(
                        onClick = { viewModel.toggleVoiceMute() },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("sound_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (uiState.voiceMuted) {
                                Icons.AutoMirrored.Outlined.VolumeMute
                            } else {
                                Icons.AutoMirrored.Outlined.VolumeUp
                            },
                            contentDescription = "Sound Toggle",
                            tint = if (uiState.voiceMuted) colors.textSecondary else colors.textPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Light / Dark Theme Toggle (Sun / Moon)
                    IconButton(
                        onClick = { viewModel.toggleTheme() },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("theme_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (uiState.isDarkTheme) {
                                Icons.Outlined.LightMode
                            } else {
                                Icons.Outlined.DarkMode
                            },
                            contentDescription = "Toggle Theme",
                            tint = colors.textPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = colors.background,
                    titleContentColor = colors.textPrimary
                )
            )
        },
        bottomBar = {
            // Minimal Bottom Navigation with 5 tabs & filled pill active indicator
            Surface(
                color = colors.card,
                border = BorderStroke(1.dp, colors.border),
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar")
            ) {
                NavigationBar(
                    containerColor = Color.Transparent,
                    tonalElevation = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    CompanionTab.entries.forEach { tab ->
                        val isSelected = uiState.activeTab == tab
                        val (icon, label) = when (tab) {
                            CompanionTab.OVERVIEW -> Icons.Outlined.Home to "Overview"
                            CompanionTab.AGENT_HUB -> Icons.Outlined.SmartToy to "Agent Hub"
                            CompanionTab.CONTROLS -> Icons.Outlined.Tune to "Controls"
                            CompanionTab.CHAT -> Icons.Outlined.ChatBubbleOutline to "AI Chat"
                            CompanionTab.MEMORY -> Icons.Outlined.Psychology to "Memory"
                        }

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 10.5.sp,
                                    maxLines = 1,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFF09221A),
                                selectedTextColor = colors.accent,
                                indicatorColor = colors.accent,
                                unselectedIconColor = colors.textSecondary,
                                unselectedTextColor = colors.textSecondary
                            ),
                            modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = uiState.activeTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                },
                label = "tab_content_transition"
            ) { activeTab ->
                when (activeTab) {
                    CompanionTab.OVERVIEW -> {
                        OverviewScreen(
                            stats = uiState.deviceStats,
                            expression = uiState.currentExpression,
                            onOptimize = { viewModel.optimizeDevice() },
                            onInspectScreen = { viewModel.inspectScreen() },
                            onOpenWhatsApp = { viewModel.triggerQuickAction("mobile.open_app", mapOf("app_name" to "WhatsApp")) },
                            onNavigateToControls = { viewModel.selectTab(CompanionTab.CONTROLS) }
                        )
                    }
                    CompanionTab.AGENT_HUB -> {
                        AgentHubScreen(
                            uiState = uiState,
                            onSendMessage = { viewModel.sendMessage(it) },
                            onPokeAvatar = { viewModel.pokeAvatar() },
                            onSelectExpression = { viewModel.setExpression(it) },
                            onToggleVoiceMute = { viewModel.toggleVoiceMute() },
                            onStartVoice = { viewModel.startVoiceListening() },
                            onStopVoice = { viewModel.stopVoiceListening() },
                            onDraftMoodPreview = { viewModel.updateMoodFromDraft(it) }
                        )
                    }
                    CompanionTab.CONTROLS -> {
                        PcBridgeScreen(
                            pcStatus = pcStatus,
                            screenVisionPreview = uiState.screenVisionPreview,
                            onConnect = { viewModel.connectPc(it) },
                            onDisconnect = { viewModel.disconnectPc() },
                            onToggleSimulated = { viewModel.toggleSimulatedBridge() },
                            onTriggerAction = { name, params -> viewModel.triggerQuickAction(name, params) }
                        )
                    }
                    CompanionTab.CHAT -> {
                        CompanionScreen(
                            uiState = uiState,
                            chatMessages = chatMessages,
                            onSendMessage = { viewModel.sendMessage(it) },
                            onToggleVoiceMute = { viewModel.toggleVoiceMute() },
                            onStartVoice = { viewModel.startVoiceListening() },
                            onStopVoice = { viewModel.stopVoiceListening() },
                            onDraftMoodPreview = { viewModel.updateMoodFromDraft(it) }
                        )
                    }
                    CompanionTab.MEMORY -> {
                        MemoryScreen(
                            memories = memories,
                            onSaveMemory = { content, cat -> viewModel.saveMemory(content, cat) },
                            onDeleteMemory = { viewModel.deleteMemory(it) }
                        )
                    }
                }
            }

            // Permission Confirmation Dialog
            uiState.pendingPermissionRequest?.let { request ->
                PermissionDialog(
                    request = request,
                    onApprove = { viewModel.approvePendingTool() },
                    onDeny = { viewModel.denyPendingTool() }
                )
            }
        }
    }
}
